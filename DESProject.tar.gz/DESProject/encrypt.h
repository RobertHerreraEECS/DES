// encrypt.h
#ifndef ENCRYPT_H
#define ENCRYPT_H

void encryptUsingRandomKey();

void printCharBinary(char* message);
#endif
